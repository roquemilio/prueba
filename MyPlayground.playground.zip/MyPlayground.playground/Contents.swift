
import UIKit

var str = "Hello, playground"

var idiomas = ["Ingles", "Frances"]

idiomas.count

